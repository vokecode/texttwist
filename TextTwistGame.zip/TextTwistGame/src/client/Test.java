package client;

import java.io.*;
import java.net.*;


public class Test
{
	public static void main(String[] args) throws IOException
	{
		MyGamePlay mpg = new MyGamePlay();
	}
}